# Assignment 2, Exercise 3

The condition for this exercise is `reflective_planning`. All conditions are included for reproducibility.

Read assignment2/RUNBOOK.md for commands, assignment2/FINAL_EXPERIMENT.md for methods, and results/analysis/ for verified tables and trace selections. Raw evidence and effective configuration are in results/MODEL/final/.

If present, assignment2/report_materials/PARTNER_GUIDE.md explains the completed results and limitations. Its full cross-version evidence links and audit commands target the Git repository handoff.

The student report and honest AI-assistance disclosure still require review and inclusion.
