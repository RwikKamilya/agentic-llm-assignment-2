"""Package one verified campaign with matching source; the student report is still required."""

import argparse
import json
import zipfile
from pathlib import Path

from assignment2.prepare_deployment import release_files
from assignment2.runner import execution_source_hashes
from assignment2.validation import validate_run_directory


ROOT = Path(__file__).resolve().parents[1]


def create_archives(campaign):
    campaign = Path(campaign).resolve()
    expected_source = execution_source_hashes(ROOT)
    for model in ['openai_mini', 'qwen_7b_local']:
        run = campaign / model / 'final'
        validate_run_directory(run)
        manifest = json.loads((run / 'manifest.json').read_text())
        if manifest['source_files'] != expected_source:
            raise ValueError('Archive source differs from the evaluated release; use the frozen release.')
    if not (campaign / 'COMPLETE').is_file():
        raise ValueError('Combined analysis has not written its COMPLETE marker.')
    output = campaign / 'packages'
    output.mkdir(exist_ok=True)
    source = release_files(ROOT)
    evidence = [path for path in campaign.rglob('*') if path.is_file() and output not in path.parents
                and (path.suffix in {'.json', '.csv', '.md', '.png', '.pdf', '.txt'} or path.name == 'COMPLETE')]
    for exercise, agent in [(1, 'naive'), (2, 'planning'), (3, 'reflective_planning')]:
        target = output / f'Ass2-{exercise}.zip'
        with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            for path in source:
                archive.write(path, path.relative_to(ROOT))
            receipt = ROOT / 'assignment2/deployed_version.json'
            if receipt.exists():
                archive.write(receipt, receipt.relative_to(ROOT))
            for path in evidence:
                archive.write(path, Path('results') / path.relative_to(campaign))
            archive.writestr('README.md',
                f'# Assignment 2, Exercise {exercise}\n\n'
                f'The condition for this exercise is `{agent}`. All conditions are included for reproducibility.\n\n'
                'Read assignment2/RUNBOOK.md for commands, assignment2/FINAL_EXPERIMENT.md for methods, '
                'and results/analysis/ for verified tables and trace selections. Raw evidence and effective '
                'configuration are in results/MODEL/final/.\n\n'
                'The student report and honest AI-assistance disclosure still require review and inclusion.\n')
            archive.writestr('ARCHIVE_STATUS.json', json.dumps({
                'status': 'VERIFIED_EVIDENCE_PACKAGED_REPORT_REVIEW_REQUIRED', 'exercise': exercise,
                'agent': agent, 'source_files': expected_source,
                'note': 'Verified real campaign, not a claim that the student report is complete.'}, indent=2))
        print(target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('campaign', help='One completed v2 campaign directory, never the entire historical results root.')
    create_archives(parser.parse_args().campaign)


if __name__ == '__main__':
    main()
